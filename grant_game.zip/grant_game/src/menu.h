/*
 * menu.h
 *
 *  Created on: May 18, 2011
 *      Author: sherwood
 */

#ifndef MENU_H_
#define MENU_H_

class menu
{
public:
	menu();

	void getmenu();
	void arrowtest(int x);

};

#endif /* MENU_H_ */
