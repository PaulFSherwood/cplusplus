/*
 * grant.h
 *
 *  Created on: May 18, 2011
 *      Author: sherwood
 */

#ifndef GRANT_H_
#define GRANT_H_

class grant
{
public:
	grant();
	// Setters
	void setHunger(int h);
	void setSmarts(int s);
	void setFun(int f);
	void setMoney(int m);
	void setHappy(int hap);

	// Getters
	int getHunger();
	int getSmarts();
	int getFun();
	int getMoney();
	int getHappy();

private:
	int Hunger;
	int Smarts;
	int Fun;
	int Money;
	int Happy;
};

#endif /* GRANT_H_ */
